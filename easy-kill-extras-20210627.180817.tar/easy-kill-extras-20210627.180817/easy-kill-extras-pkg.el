(define-package "easy-kill-extras" "20210627.180817"
  "Extra functions for easy-kill." '((easy-kill "0.9.4")) :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org")) :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org") :keywords
  '("killing" "convenience") :url
  "https://github.com/knu/easy-kill-extras.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
