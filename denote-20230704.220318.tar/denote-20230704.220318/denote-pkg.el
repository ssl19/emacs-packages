(define-package "denote" "20230704.220318"
  "Simple notes with an efficient file-naming scheme"
  '((emacs "28.1")) :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer
  '("Denote Development" . "~protesilaos/denote@lists.sr.ht") :url
  "https://git.sr.ht/~protesilaos/denote")
;; Local Variables:
;; no-byte-compile: t
;; End:
