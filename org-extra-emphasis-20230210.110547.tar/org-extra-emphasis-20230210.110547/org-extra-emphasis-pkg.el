;;; Generated package description from org-extra-emphasis.el  -*- no-byte-compile: t -*-
(define-package "org-extra-emphasis" "20230210.110547" "Extra Emphasis markers for Org" '((ox-odt "9.5.3.467")) :authors '(("Jambunathan K" . "kjambunathanatgmaildotcom")) :maintainer '("Jambunathan K" . "kjambunathanatgmaildotcom") :keywords '("org") :url "https://github.com/kjambunathan/org-extra-emphasis")
