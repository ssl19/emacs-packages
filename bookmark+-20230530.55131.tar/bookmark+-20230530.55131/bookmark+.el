;;; bookmark+.el --- Bookmark+: extensions to standard library `bookmark.el'.
;;
;; Filename: bookmark+.el
;; Description: Bookmark+: extensions to standard library `bookmark.el'.
;; Author: Drew Adams, Thierry Volpiatto
;; Maintainer: Drew Adams (concat "drew.adams" "@" "oracle" ".com")
;; Copyright (C) 2000-2022, Drew Adams, all rights reserved.
;; Copyright (C) 2009, Thierry Volpiatto, all rights reserved.
;; Created: Fri Sep 15 07:58:41 2000
;; Version: 2022.11.05
;; Last-Updated: Sat Nov  5 14:34:15 2022 (-0700)
;;           By: dradams
;;     Update #: 15074
;; URL: https://www.emacswiki.org/emacs/download/bookmark%2b.el
;; Doc URL: https://www.emacswiki.org/emacs/BookmarkPlus
;; Keywords: bookmarks, bookmark+, projects, placeholders, annotations, search, info, url, eww, w3m, gnus
;; Compatibility: GNU Emacs: 20.x, 21.x, 22.x, 23.x, 24.x, 25.x, 26.x
;;
;; Features that might be required by this library:
;;
;;   `apropos', `apropos+', `auth-source', `avoid', `backquote',
;;   `bookmark', `bookmark+', `bookmark+-1', `bookmark+-bmu',
;;   `bookmark+-key', `bookmark+-lit', `button', `bytecomp', `cconv',
;;   `cl', `cl-generic', `cl-lib', `cl-macs', `cmds-menu',
;;   `col-highlight', `crosshairs', `eieio', `eieio-core',
;;   `eieio-loaddefs', `epg-config', `fit-frame', `font-lock',
;;   `font-lock+', `frame-fns', `gv', `help+', `help-fns',
;;   `help-fns+', `help-macro', `help-macro+', `help-mode',
;;   `hl-line', `hl-line+', `info', `info+', `kmacro', `macroexp',
;;   `menu-bar', `menu-bar+', `misc-cmds', `misc-fns', `naked',
;;   `package', `password-cache', `pp', `pp+', `radix-tree', `rect',
;;   `replace', `second-sel', `seq', `strings', `syntax',
;;   `tabulated-list', `text-mode', `thingatpt', `thingatpt+',
;;   `url-handlers', `url-parse', `url-vars', `vline',
;;   `w32browser-dlgopen', `wid-edit', `wid-edit+'.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;;; Commentary:
;;
;;    Bookmark+: extensions to standard library `bookmark.el'.
;;
;;    The Bookmark+ libraries are these:
;;
;;    `bookmark+.el'     - main (driver) library (this file)
;;    `bookmark+-mac.el' - Lisp macros
;;    `bookmark+-lit.el' - (optional) code for highlighting bookmarks
;;    `bookmark+-bmu.el' - code for the `*Bookmark List*' (bmenu)
;;    `bookmark+-1.el'   - other required code (non-bmenu)
;;    `bookmark+-key.el' - key and menu bindings
;;
;;    `bookmark+-doc.el' - documentation (comment-only file)
;;    `bookmark+-chg.el' - change log (comment-only file)
;;
;;    The documentation (in `bookmark+-doc.el') includes how to
;;    byte-compile and install Bookmark+.  The documentation is also
;;    available in these ways:
;;
;;    1. From the bookmark list (`C-x r l'):
;;       Use `?' to show the current bookmark-list status and general
;;       help, then click link `Doc in Commentary' or link `Doc on the
;;       Web'.
;;
;;    2. From the Emacs-Wiki Web site:
;;       https://www.emacswiki.org/emacs/BookmarkPlus.
;;
;;    3. From the Bookmark+ group customization buffer:
;;       `M-x customize-group bookmark-plus', then click link
;;       `Commentary'.
;;
;;    (The commentary links in #1 and #3 work only if you have library
;;    `bookmark+-doc.el' in your `load-path'.)
;;
;;    To report Bookmark+ bugs: `M-x customize-group bookmark-plus'
;;    and then follow (e.g. click) the link `Send Bug Report', which
;;    helps you prepare an email to me.
;;
;;
;;    ****** NOTE ******
;;
;;      Whenever you update Bookmark+ (i.e., download new versions of
;;      Bookmark+ source files), I recommend that you do the
;;      following:
;;
;;      1. Delete all existing byte-compiled Bookmark+ files
;;         (bookmark+*.elc).
;;      2. Load Bookmark+ (`load-library' or `require').
;;      3. Byte-compile the source files.
;;
;;      In particular, always load `bookmark+-mac.el' (not
;;      `bookmark+-mac.elc') before you byte-compile new versions of
;;      the files, in case there have been any changes to Lisp macros
;;      (in `bookmark+-mac.el').
;;
;;    ******************
;;
;;
;;    ****** NOTE ******
;;
;;      On 2010-06-18, I changed the prefix used by package Bookmark+
;;      from `bookmarkp-' to `bmkp-'.  THIS IS AN INCOMPATIBLE CHANGE.
;;      I apologize for the inconvenience, but the new prefix is
;;      preferable for a number of reasons, including easier
;;      distinction from standard `bookmark.el' names.
;;
;;      This change means that YOU MUST MANUALLY REPLACE ALL
;;      OCCURRENCES of `bookmarkp-' by `bmkp-' in the following
;;      places, if you used Bookmark+ prior to this change:
;;
;;      1. In your init file (`~/.emacs') or your `custom-file', if
;;         you have one.  This is needed if you customized any
;;         Bookmark+ features.
;;
;;      2. In your default bookmark file, `bookmark-default-file'
;;         (`~/.emacs.bmk'), and in any other bookmark files you might
;;         have.
;;
;;      3. In your `*Bookmark List*' state file,
;;         `bmkp-bmenu-state-file' (`~/.emacs-bmk-bmenu-state.el').
;;
;;      4. In your `*Bookmark List*' commands file,
;;         `bmkp-bmenu-commands-file' (`~/.emacs-bmk-bmenu-commands.el'),
;;         if you have one.
;;
;;      You can do this editing in a virgin Emacs session (`emacs
;;      -Q'), that is, without loading Bookmark+.
;;
;;      Alternatively, you can do this editing in an Emacs session
;;      where Bookmark+ has been loaded, but in that case you must
;;      TURN OFF AUTOMATIC SAVING of both your default bookmark file
;;      and your `*Bookmark List*' state file.  Otherwise, when you
;;      quit Emacs your manually edits will be overwritten.
;;
;;      To turn off this automatic saving, you can use `M-~' and `M-l'
;;      in buffer `*Bookmark List*' (commands
;;      `bmkp-toggle-saving-bookmark-file' and
;;      `bmkp-toggle-saving-menu-list-state' - they are also in the
;;      `Bookmark+' menu).
;;
;;
;;      Again, sorry for this inconvenience.
;;
;;    ******************
;;
;;
;;  Commands defined here:
;;
;;    `bmkp-version'.
;;
;;  Internal variables defined here:
;;
;;    `bmkp-version-number'.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 3, or (at your option)
;; any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program; see the file COPYING.  If not, write to
;; the Free Software Foundation, Inc., 51 Franklin Street, Fifth
;; Floor, Boston, MA 02110-1301, USA.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;;; Code:

;;;;;;;;;;;;;;;;;;;;;;;

(require 'bookmark)                     ; Vanilla Emacs.

;;;###autoload (autoload 'bmkp-version-number "bookmark+")
(defconst bmkp-version-number "2018.10.17")

;;;###autoload (autoload 'bmkp-version "bookmark+")
(defun bmkp-version ()
  "Show version number of library `bookmark+.el'."
  (interactive)
  (message "Bookmark+, version %s" bmkp-version-number))

;; This was made automatically buffer-local for vanilla Emacs 28.  Do it here, for all Bookmark+ files.
(defvar bookmark-annotation-name nil
  "Name of bookmark under edit in `bookmark-edit-annotation-mode'.")
(make-variable-buffer-local 'bookmark-annotation-name)

;;;###autoload (autoload 'bookmark-bmenu-buffer "bookmark+")
;; This was added for vanilla Emacs 28.  Add it here for older releases.
(defconst bookmark-bmenu-buffer "*Bookmark List*"
  "Name of buffer used by vanilla Emacs for the bookmark-list display.")

;;;###autoload (autoload 'bookmark-plus "bookmark+")
(defgroup bookmark-plus nil
  "Bookmark enhancements."
  :prefix "bmkp-" :group 'bookmark
  :link `(url-link :tag "Send Bug Report"
          ,(concat "mailto:" "drew.adams" "@" "oracle" ".com?subject=\
Bookmark+ bug: \
&body=Describe bug here, starting with `emacs -Q'.  \
Don't forget to mention your Emacs and library versions."))
  :link '(url-link :tag "Download" "https://www.emacswiki.org/emacs/download/bookmark%2b.el")
  :link '(url-link :tag "Description" "https://www.emacswiki.org/emacs/BookmarkPlus")
  :link '(emacs-commentary-link :tag "Commentary" "bookmark+"))

;; NOTE:
;; $$$$$$ Currently all vanilla Emacs functions that use constant `bookmark-bmenu-buffer' are
;; already redefined for Bookmark+.  But if vanilla Emacs adds more such functions, and if those
;; functions could be invoked somehow when using Bookmark+, and if `bmkp-bmenu-buffer' has a
;; different value from `bookmark-bmenu-buffer', then some adjustment of Bookmark+ code will be
;; needed, to make sure the `bmkp-bmenu-buffer' value gets used instead.
;;
;;;###autoload (autoload 'bmkp-bmenu-buffer "bookmark+")
(defcustom bmkp-bmenu-buffer bookmark-bmenu-buffer
  "Name of buffer used by Bookmark+ for the bookmark-list display.
The default value is that of vanilla Emacs constant `bookmark-bmenu-buffer'."
  :type 'string :group 'bookmark-plus)



;; Load Bookmark+ libraries.
;;
(eval-when-compile
 (or (condition-case nil
         (load-library "bookmark+-mac") ; Lisp macros.
       (error nil))                     ; Use load-library to ensure latest .elc.
     (require 'bookmark+-mac)))         ; Require, so can load separately if not on `load-path'.

(require 'bookmark+-lit nil t)          ; Optional (soft require) - no error if not found.  If you do
                                        ; not want to use `bookmark+-lit.el' then simply do not put
                                        ; that file in your `load-path'.
(require 'bookmark+-bmu)                ; `*Bookmark List*' (aka "menu list") stuff.
(require 'bookmark+-1)                  ; Rest of Bookmark+, except keys & menus.
(require 'bookmark+-key)                ; Keys & menus.

;;;;;;;;;;;;;;;;;;;;;;;

(provide 'bookmark+)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;; bookmark+.el ends here
