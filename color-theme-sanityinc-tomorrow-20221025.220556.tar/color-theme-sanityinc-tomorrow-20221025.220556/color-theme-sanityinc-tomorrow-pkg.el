(define-package "color-theme-sanityinc-tomorrow" "20221025.220556"
  "A version of Chris Kempson's \"tomorrow\" themes" 'nil :authors
  '(("Steve Purcell" . "steve@sanityinc.com")) :maintainer
  '("Steve Purcell" . "steve@sanityinc.com") :keywords
  '("faces" "themes") :url
  "https://github.com/purcell/color-theme-sanityinc-tomorrow")
;; Local Variables:
;; no-byte-compile: t
;; End:
