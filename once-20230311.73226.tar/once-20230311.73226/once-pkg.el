(define-package "once" "20230311.73226"
  "Extra init.el deferred evaluation utilties" '((emacs "26.1"))
  :authors '(("Fox Kiester" . "noctuid@pir-hana.cafe")) :maintainer
  '("Fox Kiester" . "noctuid@pir-hana.cafe") :keywords
  '("convenience" "dotemacs" "startup" "config") :url
  "https://github.com/emacs-magus/once")
;; Local Variables:
;; no-byte-compile: t
;; End:
