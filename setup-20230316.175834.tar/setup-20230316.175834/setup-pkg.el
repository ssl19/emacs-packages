;;; Generated package description from setup.el  -*- no-byte-compile: t -*-
(define-package "setup" "20230316.175834" "Helpful Configuration Macro" '((emacs "26.1")) :authors '(("Philip Kaludercic" . "philipk@posteo.net")) :maintainer '("Philip Kaludercic" . "~pkal/public-inbox@lists.sr.ht") :keywords '("lisp" "local") :url "https://git.sr.ht/~pkal/setup")
