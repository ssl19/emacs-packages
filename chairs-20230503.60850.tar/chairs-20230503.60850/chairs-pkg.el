;;; Generated package description from chairs.el  -*- no-byte-compile: t -*-
(define-package "chairs" "20230503.60850" "CHAnge and Add surrounding pAIRS" '((emacs "28.1") (expand-region "0.7")) :keywords '("extensions" "convenience") :url "https://github.com/ssl19/chairs.el")
