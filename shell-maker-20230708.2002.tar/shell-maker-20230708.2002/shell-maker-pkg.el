(define-package "shell-maker" "20230708.2002" "Interaction mode for making comint shells"
  '((emacs "27.1"))
  :commit "c088ca369e4be6788203d2602977021123a3c491" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
