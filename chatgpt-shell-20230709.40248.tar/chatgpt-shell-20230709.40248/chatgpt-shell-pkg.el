(define-package "chatgpt-shell" "20230709.40248"
  "ChatGPT shell + buffer insert commands"
  '((emacs "27.1") (shell-maker "0.40.1")) :url
  "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
